export function mvpSelectId(lobbyId: string, teamId: string) { return `VOTE:MVP:${lobbyId}:${teamId}`; }
export function mvpLockId(lobbyId: string) { return `VOTE:LOCK:${lobbyId}`; }
