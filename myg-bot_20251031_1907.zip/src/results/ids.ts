export function resultWinId(matchId: string, teamId: string) { return `RESULT:WIN:${matchId}:${teamId}`; }
export function resultFinalizeId(lobbyId: string) { return `RESULT:FINALIZE:${lobbyId}`; }
