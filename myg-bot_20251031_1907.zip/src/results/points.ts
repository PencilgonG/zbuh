export const WIN_POINTS = 3;
export const LOSS_POINTS = 1;

// Barème MVP par team (classement interne à l'équipe)
export const MVP_POINTS = [3, 2, 1]; // 1er=+3, 2e=+2, 3e=+1
