export function matchStartId(matchId: string)  { return `MATCH:START:${matchId}`; }    // créer room + envoyer embed
export function matchValidateId(matchId: string) { return `MATCH:VALIDATE:${matchId}`; } // respo only
